# SEMAT 2026 · Projeto Lean dos participantes

Cynthia Bortolotto · 26 de outubro de 2026

Abra esta pasta completa no VS Code e siga [Instalação](participantes/Instalacao.md).
Primeiro confira [TesteInstalacao.lean](participantes/TesteInstalacao.lean), depois acompanhe
[Aula.lean](participantes/Aula.lean). A prática principal termina em Cauchy–Schwarz.

Consulte [Guia.md](participantes/Guia.md). O quiz e os projetos de involução e Mathlib
são materiais complementares. Os avisos de `sorry` nos exercícios são esperados.

Este ZIP contém o projeto Lean. A apresentação e todos os materiais estão em:
https://github.com/cynthiabort/SEMAT-Lean-2026

Versões: Lean 4.30.0 e Mathlib v4.30.0. Preserve os arquivos de configuração.
As dependências são baixadas na preparação inicial; as soluções ficam com a docente.
